/**
 * Classe de teste que imprime uma mensagem.
 */
public class Teste {
  /**
   * Método principal.
   *
   * @param args argumentos de linha de comando (não utilizados).
   */
  public static void main(String[] args) {
    if (true) {
      System.out.println("Tudo certo, sem erros!");
    }
  }
}
