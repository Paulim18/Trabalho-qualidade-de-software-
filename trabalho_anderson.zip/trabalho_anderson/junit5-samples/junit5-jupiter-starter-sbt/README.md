# junit5-jupiter-starter-sbt

The `junit5-jupiter-starter-sbt` project demonstrates how to run tests based on JUnit
Jupiter using [sbt] and its [sbt-jupiter-interface] plugin and code and tests written in Scala.

[sbt]: https://docs.gradle.org/current/userguide/java_testing.html#using_junit5
[sbt-jupiter-interface]: https://github.com/sbt/sbt-jupiter-interface
