# junit5-jupiter-starter-maven-kotlin

The `junit5-jupiter-starter-maven-kotlin` sample demonstrates the bare minimum configuration for
getting started with JUnit Jupiter project using Maven build system and Kotlin programming language.

Please note that this project is uses the [Maven Wrapper](https://github.com/takari/maven-wrapper)
3.6.1 version. This helps you ensure that already tested versions are not going to be failed if
locally installed different maven version.
